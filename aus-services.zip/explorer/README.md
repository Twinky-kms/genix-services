# Explorer

This is a collection of Docker containers that creates an Iquidus explorer with attached Mongo database and AustraliaCash node.

The default port is 3000 but this can be modified in `docker-compose.yml`


1. Install Docker
2. `cd /explorer`
3. `docker-compose up --build -d`