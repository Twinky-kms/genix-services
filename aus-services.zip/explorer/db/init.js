db.createUser({
  user: "aus_explorer",
  pwd: "dbpassword",
  roles: ["readWrite"]
});
